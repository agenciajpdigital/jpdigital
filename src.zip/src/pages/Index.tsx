import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import HowItWorks from "@/components/HowItWorks";
import AboutUs from "@/components/AboutUs";
import Reviews from "@/components/Reviews";
import LocationSection from "@/components/LocationSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import AgentFloat from "@/components/AgentFloat";
import DiagnosticModal from "@/components/DiagnosticModal";
import RecorrenciaHome from "@/components/RecorrenciaHome";
import RecorrenciaMensalHome from "@/components/RecorrenciaMensalHome";

const Index = () => {
  const [quizOpen, setQuizOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Header onOpenQuiz={() => setQuizOpen(true)} />
      <Hero onOpenQuiz={() => setQuizOpen(true)} />
      <Services />
      <RecorrenciaMensalHome onOpenQuiz={() => setQuizOpen(true)} />
      <RecorrenciaHome onOpenQuiz={() => setQuizOpen(true)} />
      <HowItWorks />
      <AboutUs />
      <Reviews />
      <LocationSection onOpenQuiz={() => setQuizOpen(true)} />
      <ContactSection onOpenQuiz={() => setQuizOpen(true)} />
      <Footer />
      <WhatsAppFloat onOpenQuiz={() => setQuizOpen(true)} />
      <AgentFloat onOpenQuiz={() => setQuizOpen(true)} />
      <DiagnosticModal open={quizOpen} onClose={() => setQuizOpen(false)} />
    </div>
  );
};

export default Index;
